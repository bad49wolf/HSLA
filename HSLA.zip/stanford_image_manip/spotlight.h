#ifndef SPOTLIGHT_H
#define SPOTLIGHT_H
#include "image.h"

class spotlight : public image
{
public:
    using image::image;
    spotlight(string filename, int centerX, int centerY);
    int getDistance(int x1,int y1,int x2,int y2);
    void createSpotlight();
    int centerX;
    int centerY;

};

#endif // SPOTLIGHT_H

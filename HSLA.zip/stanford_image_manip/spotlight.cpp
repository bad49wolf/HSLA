#include "spotlight.h"
#include "image.h"
#include <math.h>
spotlight::spotlight(string filename, int centerX, int centerY):image()
{

readFromFile(filename);
this->centerX=centerX;
this->centerY=centerY;
int xx=0, yy=0,z;
for (unsigned x = 0; x < width(); x++) {
        for (unsigned y = 0; y < height(); y++) {
        HSLAPixel & pixel = getPixel(x, y);
        xx=x-centerX;
        yy=y-centerY;
        z=sqrt((xx*xx)+(yy*yy));
        if(z<160)
                pixel.l=pixel.l-.005*z*pixel.l;
        else
                pixel.l = pixel.l - 0.8*pixel.l;

        }
    }
}
int spotlight::getDistance(int x1,int y1,int x2,int y2) {
    return sqrt((x2-x1)^2+(y2-y1)^2);
}
void spotlight::createSpotlight() {



}

#ifndef GRAYSCALE_H
#define GRAYSCALE_H


class grayscale
{
public:
    grayscale();
};

#endif // GRAYSCALE_H

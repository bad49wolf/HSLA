#ifndef ILLINI_H
#define ILLINI_H


class illini
{
public:
    illini();
};

#endif // ILLINI_H

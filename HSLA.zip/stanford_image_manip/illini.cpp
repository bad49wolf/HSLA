#include "illini.h"

illini::illini()
{

}

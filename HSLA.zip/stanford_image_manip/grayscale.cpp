#include "grayscale.h"

grayscale::grayscale()
{

    for (unsigned x = 0; x < image.width(); x++) {
        for (unsigned y = 0; y < image.height(); y++) {
          HSLAPixel & pixel = image.getPixel(x, y);

          // `pixel` is a reference to the memory stored inside of the PNG `image`,
          // which means you're changing the image directly. No need to `set`
          // the pixel since you're directly changing the memory of the image.
          pixel.s = 0;
        }
      }
}

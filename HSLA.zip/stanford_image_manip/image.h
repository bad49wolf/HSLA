#ifndef IMAGE_H
#define IMAGE_H
#include <string>
#include "PNG.h"
using namespace std;

class image : public PNG
{
public:
    using PNG::PNG;
    image(string);
    double amm=0.005;
    void lighten (double amount=0.1);
    void saturate (double amount=0.1);
    void rotateAngle(double angle);
};

#endif // IMAGE_H

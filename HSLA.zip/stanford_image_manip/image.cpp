#include "image.h"

image::image(string filename):PNG()
{
readFromFile(filename);

}
void image::lighten(double amount) {
    for(unsigned x=0; x<width(); x++)
        for(unsigned y=0; y<height(); y++){
            HSLAPixel &P=getPixel(x,y);
            P.l += amount;
            //ne pas depasser 1
            P.l = (P.l <1)? P.l :1;
            // ne pas depasser 0
            P.l=(P.l<0)? 0 : P.l;


        }
   }
    void image::saturate(double amount) {
        for(unsigned x=0; x<width(); x++)
            for(unsigned y=0; y<height(); y++){
                HSLAPixel &P=getPixel(x,y);
                P.s += amount;
                //ne pas depasser 1
                P.s = (P.l <1)? P.l :1;
                // ne pas depasser 0
                P.s=(P.l<0)? 0 : P.l;


            },
        }
        void image::rotateAngle(double angle) {
            for(unsigned x=0; x<width(); x++)
                for(unsigned y=0; y<height(); y++){
                    HSLAPixel &P=getPixel(x,y);
                    P.h += angle;
                    //ne pas depasser 360
                    while (P.h>360)
                        P.h -= 360;

                    // ne pas depasser 0
                    while (P.h<360)
                        P.h += 360;

                }
               }
